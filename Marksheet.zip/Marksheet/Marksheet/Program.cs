﻿class A
{
    public int m1, m2, m3, total, per;
    public string result, grade;
}
class B : A
{
    public void get()
    {
        Console.Write("Enter mark 1 :");
        m1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter mark 2 :");
        m2 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter mark 3 :");
        m3 = Convert.ToInt32(Console.ReadLine());
    }
}
class c : B
{
    public void result()
    {
        total = m1 + m2 + m3;

        if(m1 >=33 && m2 >= 33 && m3 >= 33 &&)
        {
            per = total / 3;
            result = "pass";
            if(per>=70)
            {
                grade = "Distingtion";
            }

            else if(per>=60)
            {
                grade = "First class";
            }
            else if(per >=50)
            {
                grade = "Second";
            }
            else
            {
                grade = "pass";
            }
        }
        else
        {
            per = 0;
            result = "fail";
            grade = "fail";
        }
    }
}
class D : c
{
    D dd = new D();
    dd.get)()
}

